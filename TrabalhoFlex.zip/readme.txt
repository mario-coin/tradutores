#Compilar o flex com a linha de comando abaixo:
.\flex.exe pascaltoy.lex



Site para compilar o C

https://www.onlinegdb.com/online_c_compiler